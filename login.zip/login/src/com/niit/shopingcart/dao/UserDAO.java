package com.niit.shopingcart.dao;

public class UserDAO 
{
	public boolean isValidCredentials (String userID,String password)
	{
		if(userID.equals("NIIT")&& password.equals("123"))
		{
			return true;
		}
		else 
		{
			return false;
		}
	}
}