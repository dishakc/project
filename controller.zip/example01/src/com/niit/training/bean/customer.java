package com.niit.training.bean;

import java.util.ArrayList;
import java.util.List;

public class customer extends User
{
	private List myAccounts = new ArrayList() ;
	 
	public List getMyAccounts() {
		return myAccounts;
	}
	public void setMyAccounts(List myAccounts) {
		this.myAccounts = myAccounts;
	}
	
	
	
	Account a1 = new Account();
	Account a2 = new Account();
	Account a3 = new Account();
	
	
	
	
	
	
	
	
	private String shippingAddress;
	private String permanetAdress;
	public String getShippingAddress() {
		return shippingAddress;
	}
	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}
	public String getPermanebtadress() {
		return permanetAdress;
	}
	public void setPermanetAdress(String permanetAdress) {
		this.permanetAdress = permanetAdress;
	}
	
}