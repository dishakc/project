package com.niit.shopingcart;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shopingcart.dao.SupplierDAO;

public class SupplierTest 
{

AnnotationConfigApplicationContext context;
	
	SupplierDAO supplierDAO;
	
	@BeforeClass
	public void init()

	{
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shopingcart");
		context.refresh();
		supplierDAO=(SupplierDAO)context.getBean("supplierDAO");	
	}
	

	@Test
	public void ListTest() 
	{
		assertEquals("ListSupplier",23,supplierDAO.list().size());
	}
	
	@Test
	public void getTest() 
	{
		
	}
	
	@Test
	public void getByNameTest() 
	{
		
	}
	
	
	@Test
	public void saveOrUpdateTest() 
	{
		
	}
	
	@Test
	public void deleteTest() 
	{
		
	}
	
	

}
