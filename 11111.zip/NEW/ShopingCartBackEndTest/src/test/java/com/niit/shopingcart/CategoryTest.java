package com.niit.shopingcart;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shopingcart.dao.CategoryDAO;

public class CategoryTest 
{	
	AnnotationConfigApplicationContext context;
	
	CategoryDAO categoryDAO;
	
	@BeforeClass
	public void init()

	{
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shopingcart");
		context.refresh();
		categoryDAO=(CategoryDAO)context.getBean("categoryDAO");	
	}
	

	@Test
	public void ListTest() 
	{
		assertEquals("ListCategory",11,categoryDAO.list().size());
	}
	
	@Test
	public void getTest() 
	{
		
	}
	
	@Test
	public void getByNameTest() 
	{
		
	}
	
	
	@Test
	public void saveOrUpdateTest() 
	{
		
	}
	
	@Test
	public void deleteTest() 
	{
		
	}
	
	

}
