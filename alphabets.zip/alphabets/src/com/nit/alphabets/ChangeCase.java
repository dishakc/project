package com.nit.alphabets;



public class ChangeCase
{
    public static void main (String args[])
    {	
    	char c = 'a';
    	int t;
    	char b;
    	for (c= 'a';c<='z';c++)
    	{
    		System.out.println(c);
    		t = c-32;
    		System.out.println((char)t);
    	}
    }
}