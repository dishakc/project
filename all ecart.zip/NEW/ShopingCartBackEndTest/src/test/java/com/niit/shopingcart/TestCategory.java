package com.niit.shopingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shopingcart.dao.CategoryDAO;
import com.niit.shopingcart.model.Category;

public class TestCategory 
{
	public static void main(String[] args) 
	{
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shopingcart");
		context.refresh();
		
		CategoryDAO categoryDAO= (CategoryDAO)context.getBean("categoryDAO");
		
		Category category = (Category)context.getBean("category");

		category.setId("CG_002");
		category.setName("cg002");
		category.setDescription("this is another cg");
		
		categoryDAO.saveOrUpdate(category);
		
	}
}
