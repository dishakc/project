package com.niit.shopingcart.model;

public class Category {

}
