package com.niit.shopingcart.config;

import java.util.Properties;


@Configuration
@ComponentScan("com.niit.shopingcart")
@EnableTransactionManagment
public class ApplicationContextConfig 
{
	@Bean(name = "dataSource")
	public DataSource getDataSource()
	{
		
	}
}
