package com.niit.ecart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.ecart.dao.ProductDAO;
import com.niit.ecart.bean.Product;

@Controller
public class ProductController 
{
	@Autowired
	ProductDAO productDAO;

	@RequestMapping("/getAllProducts")
	public ModelAndView getAllProducts() 
	{
		System.out.println("getAllProducts");
		
		List <Product> productList = productDAO.getAllProducts();  // Fetching Product list from DAO 
		
		ModelAndView mv = new ModelAndView("/productList");   // navigating to view (to productList.jsp)
		mv.addObject("productList", productList);            // and adding product list to key, using this key list object can be retrieved in productList.jsp
		
		return mv;

	}
}
