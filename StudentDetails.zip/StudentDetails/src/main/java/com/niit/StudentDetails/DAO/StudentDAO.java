package com.niit.StudentDetails.DAO;

import java.util.List;

import com.niit.StudentDetails.model.Student;

public interface StudentDAO 
{
	public List<Student> list();
	public Student get(String id);

	public void saveOrUpdate(Student student);

	public void delete(String id);

	public boolean isValidUser(String id, String name);


}
