package com.niit.StudentDetails.test;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.StudentDetails.DAO.StudentDAO;
import com.niit.StudentDetails.model.Student;

public class Test 
{
static AnnotationConfigApplicationContext context;
	
	public Test()
	{
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.StudentDetails");
		context.refresh();
	}
	
	public static void createStudent(Student student)
	{
		
		StudentDAO  studentDAO =  (StudentDAO) context.getBean("studentDAO");
		studentDAO.saveOrUpdate(student);
		
		
	}
	
	

	public static void main(String[] args) {
		
		Test t = new Test();
		
		Student student =(Student)  context.getBean("student");
		student.setId("admin");
		student.setName("admin");
		
		
		
		t.createStudent(student);
		
		
	}

	private static void display(List<Student> list) {
		for( Student c : list)
		{
			System.out.print(c.getId() + ":"+ c.getName()) ;
		}
		
	}

}
