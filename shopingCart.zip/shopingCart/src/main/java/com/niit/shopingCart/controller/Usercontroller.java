package com.niit.shopingCart.controller;

import com.niit.shopingCart.dao.UserDAO;

@Controller
public class Usercontroller 
{
	@Autowired
	UserDAO userDAO;
	
	@RequestMapping("/isValidUser")
	public ModelAndView showMessage(@RequestParam(value = "name")String name,@RequestParam(value="password") String password)
	{
		System.out.println("in controller");
		String message;
		if (userDAO.isValidUser(name,password))
		{
			message="Valid credentials";
		}
		else
		{
			message = "Invalid credentials";
		}
		ModelAndView mv = new ModelAndView("sucess");
		mv.addObject("message",message);
		mv.addObject("name",name);
		//mv.addObject("password",password);
		return mv;
	}
}